#include <stdio.h>
#include <string.h>

#include "def.h"

#include <coredef.h>
#include <struct.h>
#include <poslib.h>

const APP_MSG App_Msg = {
        "Demo",
        "Demo-App",
        "V220913",
        "VANSTONE",
        __DATE__ " " __TIME__,
        "",
        0,
        0,
        0,
        "00001001140616"
};


void MenuThread();

//function();

/*
*******************************Connect Wifi*******************************
*/

int function(void) {
    unsigned char *RecBuff;
    unsigned short *RecLen;
    int ret, ret2;
    ret = Connect();

    ret2 = CommTxd_Api("1", 1, 0);

    memset(RecBuff, 0, sizeof(RecBuff));
    ret2 = CommRxd_Api(RecBuff, &RecLen, 1, 0, 5000);
    TipAndWaitEx_Api("CommRxd_Api = %02x", ret2);

    CommClose_Api();

    return 0;
}

int Connect(void) {
    MAINLOG_L1("Wifi Connected 1");
    int ret;

#define _HOSTIP_ "172.17.201.100"
#define _HOSTPORT_ "1883"
//    EXTERN struct _COMMPARASTRUC_ G_CommPara;
    struct _COMMPARASTRUC_ G_CommPara;


    memset(&G_CommPara, 0, sizeof(struct _COMMPARASTRUC_));

    strcpy((char *) G_CommPara.WifiSet.SSID, "ACLEDA-GUEST"); //the name of your wifi
    G_CommPara.WifiSet.SecurityType = 3;
    G_CommPara.WifiSet.EncryptType = 3;
    strcpy((char *) G_CommPara.WifiSet.WpaPsk, "acleda123*");  //the password of your wifi
    G_CommPara.WifiSet.Dhcp = 1;

//    strcpy((char *) G_CommPara.NetSet.NetServerIp, _HOSTIP_);   //the ip address you want to connect
//    strcpy((char *) G_CommPara.NetSet.NetServerPort, _HOSTPORT_);  //the commport of the ip address
//    strcpy((char *) G_CommPara.NetSet.NetServer2Ip, _HOSTIP_);
//    strcpy((char *) G_CommPara.NetSet.NetServer2Port, _HOSTPORT_);

    G_CommPara.CurCommMode = WIFI;
//    SaveCommParam();    //this function is not necessary

    ret = CommModuleInit_Api(&G_CommPara);
    MAINLOG_L1("Wifi Connected", ret);

    CommParamSet_Api(&G_CommPara);
    WaitAnyKey_Api(3);

    ret = CommStart_Api();

    ret = CommCheck_Api(30);
    TipAndWaitEx_Api("CommCheck_Api = %d", ret);

    return 0;
}

#define COMMPARAMFILE   "CommParamFile"
//struct COMMPARASTRUC G_CommPara;

void SaveCommParam(void) {
    u8 result;

    do {
        result = WriteFile_Api(COMMPARAMFILE, (u8 * ) & G_CommPara, 0, sizeof(struct _COMMPARASTRUC_));
    } while (result != 0);
}


/*
*******************************End Connect Wifi*******************************
*/

void InitSys(void) {

    int ret;
    unsigned char bp[32];

    // Turn on debug output to serial COM
    SetApiCoreLogLevel(5);

    // Load parameters
    initParam();

    //initializes device type
    initDeviceType();

#ifdef __WIFI__

    NetModuleOper_Api(GPRS, 0);
    ret = NetModuleOper_Api(WIFI, 1);
    MAINLOG_L1("NetModuleOper_Api wifi:%d",ret);

    ret = wifiOpen_lib();
    MAINLOG_L1("wifiOpen_lib:%d", ret);

    ApConnect();

#else

    // Turn off WIFI and turn on 4G network
    NetModuleOper_Api(WIFI, 0);
    NetModuleOper_Api(GPRS, 1);

#endif

    // Network initialization
    net_init();

    // MQTT client initialization
    initMqttOs();

    ret = fibo_thread_create(MenuThread, "mainMenu", 14 * 1024, NULL, 1);
    MAINLOG_L1("fibo_thread_create: %d", ret);

#ifdef __TMSTHREAD__
    ret = fibo_thread_create(TMSThread, "TMSThread", 14*1024, NULL, 1);
    MAINLOG_L1("fibo_thread_create: %d", ret);
#endif

    //check if any app to update
    ret = checkAppUpdate();
    if (ret < 0)
        set_tms_download_flag(1);


    //Common_DbgEN_Api(1);

    memset(bp, 0, sizeof(bp));
    ret = sysReadBPVersion_lib(bp);
    MAINLOG_L1("Firmware Version == %d, version: %s", ret, bp);

    memset(bp, 0, sizeof(bp));
    ret = sysReadVerInfo_lib(4, bp);
    MAINLOG_L1("lib Version == %d, version: %s, APP Version: %s", ret, bp, App_Msg.Version);

}

int AppMain(int argc, char **argv) {
    int ret;
    int wif;
    int signal_lost_count;
    int mobile_network_registered;

    SystemInit_Api(argc, argv);

//	QRlogo();

    InitSys();

    signal_lost_count = 0;
    mobile_network_registered = 0;


    while (1) {

#ifdef __WIFI__

        //int wifiGetStatus_lib(void);
        ret = wifiGetLinkStatus_lib();
        MAINLOG_L1("wifiGetLinkStatus_lib:%d", ret);
        if(ret == 5) //AP not connected
        {
            if(ApConnect() != 0)
            {
                Delay_Api(5000);
                continue;
            }
        }
        else if(ret == -6300) // not open
        {
           ret = wifiOpen_lib();
           MAINLOG_L1("wifiOpen_lib:%d", ret);
           if((ret != 0) || (ApConnect() != 0))
           {
               Delay_Api(5000);
               continue;
           }
        }
        else if(ret == -6302) // check status failed
        {
            AppPlayTip("Mobile network registration in progress");
            Delay_Api(10000);
            continue;
        }
        mQTTMainThread();
        AppPlayTip("Server connection lost");

#else
        // Check mobile network status
        ret = NetLinkCheck_Api(GPRS);
        MAINLOG_L1("*******************4G status:%d", ret);

        if (ret == 2) {
            AppPlayTip("Please insert sim card and restart device");
            Delay_Api(60000);
            //SysPowerReBoot_Api();
            continue;
        } else if (ret == 1) {
            if (signal_lost_count > 10) {
                AppPlayTip("Cannot register mobile network, restarting device");
                Delay_Api(60000);
                //SysPowerReBoot_Api();
                continue;
            }

            AppPlayTip("Mobile network registration in progress");

            Delay_Api(3000);
            signal_lost_count++;
            mobile_network_registered = 0;
            continue;
        } else {
            signal_lost_count = 0;

            if (mobile_network_registered == 0) {
                mobile_network_registered = 1;
                //AppPlayTip("Mobile network registered");
            }
        }

//		ScrClrLine_Api(LINE7, LINE7);
//		ScrDisp_Api(LINE7, 0, "connecting...", CDISP);

        mQTTMainThread();
        AppPlayTip("Server connection lost");

#endif

    }

    return 0;
}





